require('DistributeCities')

function Server_StartDistribution(game, standing)
    DistributeCities(game, standing);
end

