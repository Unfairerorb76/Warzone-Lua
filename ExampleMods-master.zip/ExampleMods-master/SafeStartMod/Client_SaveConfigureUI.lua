
function Client_SaveConfigureUI(alert)
    
    Mod.Settings.NumTurns = numberInputField.GetValue();
end
