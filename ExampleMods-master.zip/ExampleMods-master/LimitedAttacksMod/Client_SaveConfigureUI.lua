
function Client_SaveConfigureUI(alert)
    Mod.Settings.Limit = numberInputField.GetValue();
end
