require('RandomizeWastelands')

function Server_StartDistribution(game, standing)
    RandomizeWastelands(game, standing);
end

