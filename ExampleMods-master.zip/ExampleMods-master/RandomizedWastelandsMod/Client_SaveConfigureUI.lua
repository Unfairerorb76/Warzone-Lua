
function Client_SaveConfigureUI(alert)
    
    Mod.Settings.RandomizeAmount = numberInputField.GetValue();
end