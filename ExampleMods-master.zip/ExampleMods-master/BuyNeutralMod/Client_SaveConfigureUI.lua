
function Client_SaveConfigureUI(alert)
    
    Mod.Settings.CostPerNeutralArmy = numberInputField.GetValue();
end