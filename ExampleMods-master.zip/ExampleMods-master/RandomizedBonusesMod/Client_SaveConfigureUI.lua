
function Client_SaveConfigureUI(alert)
    
    Mod.Settings.RandomizeAmount = numberInputField.GetValue();
	Mod.Settings.AllowNegative = allowNegativeBonusesCheckBox.GetIsChecked();
end
